import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-checklist',
  templateUrl: './common-dashboard-checklist.component.html',
  styleUrls: ['./common-dashboard-checklist.component.scss']
})
export class CommonDashboardChecklistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
