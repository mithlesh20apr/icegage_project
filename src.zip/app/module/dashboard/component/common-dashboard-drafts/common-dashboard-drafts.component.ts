import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-drafts',
  templateUrl: './common-dashboard-drafts.component.html',
  styleUrls: ['./common-dashboard-drafts.component.scss']
})
export class CommonDashboardDraftsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
