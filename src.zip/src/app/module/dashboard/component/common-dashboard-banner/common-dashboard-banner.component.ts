import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-banner',
  templateUrl: './common-dashboard-banner.component.html',
  styleUrls: ['./common-dashboard-banner.component.scss']
})
export class CommonDashboardBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
