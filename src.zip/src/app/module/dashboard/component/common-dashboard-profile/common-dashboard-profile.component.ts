import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard-profile',
  templateUrl: './common-dashboard-profile.component.html',
  styleUrls: ['./common-dashboard-profile.component.scss']
})
export class CommonDashboardProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
