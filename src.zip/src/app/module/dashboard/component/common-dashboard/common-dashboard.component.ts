import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-dashboard',
  templateUrl: './common-dashboard.component.html',
  styleUrls: ['./common-dashboard.component.scss']
})
export class CommonDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
